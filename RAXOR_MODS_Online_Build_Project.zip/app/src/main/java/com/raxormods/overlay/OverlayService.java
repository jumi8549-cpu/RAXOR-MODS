package com.raxormods.overlay;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Switch;

public class OverlayService extends Service {
    private WindowManager wm;
    private View panel;
    private WindowManager.LayoutParams params;
    private int pink = Color.rgb(255, 20, 147);

    @Override public void onCreate() {
        super.onCreate();
        makeNotification();
        showPanel();
    }

    private void makeNotification() {
        String channel = "raxor_overlay";
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(channel, "RAXOR Overlay",
                NotificationManager.IMPORTANCE_LOW));
        }
        Notification n = new Notification.Builder(this, channel)
            .setContentTitle("RAXOR MODS aktif")
            .setContentText("Overlay visual sedang berjalan")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build();
        startForeground(7, n);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(10, 8, 10, 8);
        return t;
    }

    private void showPanel() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(12, 10, 12, 12);
        card.setBackgroundColor(pink);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("RAXOR MODS", 17, Color.WHITE);
        title.setTypeface(null, 1);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button close = new Button(this);
        close.setText("×");
        close.setTextSize(18);
        close.setTextColor(pink);
        close.setOnClickListener(v -> stopSelf());
        top.addView(close, new LinearLayout.LayoutParams(48, 44));
        card.addView(top);

        TextView subtitle = text("KERNEL EXTERNAL V1  •  VISUAL DEMO", 10, Color.WHITE);
        card.addView(subtitle);

        addDemoSwitch(card, "Panel demo 01");
        addDemoSwitch(card, "Panel demo 02");
        addDemoSwitch(card, "Panel demo 03");

        Button hide = new Button(this);
        hide.setText("MINIMIZE");
        hide.setTextColor(pink);
        hide.setOnClickListener(v -> {
            if (panel != null) {
                wm.removeView(panel);
                panel = null;
                showBubble();
            }
        });
        card.addView(hide);

        panel = card;
        params = new WindowManager.LayoutParams(
            290, WindowManager.LayoutParams.WRAP_CONTENT,
            Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 24; params.y = 140;
        attachDrag(card, params);
        wm.addView(panel, params);
    }

    private void addDemoSwitch(LinearLayout parent, String label) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(Color.WHITE);
        s.setPadding(10, 5, 10, 5);
        s.setChecked(false);
        s.setOnCheckedChangeListener((button, checked) -> { /* visual demo only */ });
        parent.addView(s);
    }

    private void showBubble() {
        TextView bubble = text("R", 18, Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackgroundColor(pink);
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            58, 58,
            Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.LEFT; p.x = 18; p.y = 180;
        bubble.setOnClickListener(v -> {
            try { wm.removeView(bubble); } catch (Exception ignored) {}
            showPanel();
        });
        attachDrag(bubble, p);
        wm.addView(bubble, p);
    }

    private void attachDrag(View view, WindowManager.LayoutParams p) {
        view.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy; float tx, ty;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    sx = p.x; sy = p.y; tx = e.getRawX(); ty = e.getRawY(); return false;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    p.x = sx + (int)(e.getRawX() - tx);
                    p.y = sy + (int)(e.getRawY() - ty);
                    try { wm.updateViewLayout(view, p); } catch (Exception ignored) {}
                    return true;
                }
                return false;
            }
        });
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }
    @Override public void onDestroy() {
        if (panel != null) { try { wm.removeView(panel); } catch (Exception ignored) {} panel = null; }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
