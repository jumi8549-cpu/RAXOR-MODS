package com.raxormods.overlay;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    private final int PINK = Color.rgb(255, 20, 147);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("RAXOR MODS\nKERNEL EXTERNAL V1");
        title.setTextColor(PINK);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        title.setPadding(12, 12, 12, 28);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Floating overlay visual mandiri. Tidak terhubung ke game atau memodifikasi gameplay.");
        info.setTextColor(Color.DKGRAY);
        info.setTextSize(15);
        info.setGravity(Gravity.CENTER);
        info.setPadding(8, 8, 8, 24);
        root.addView(info);

        Button start = new Button(this);
        start.setText("AKTIFKAN FLOATING PANEL");
        start.setTextColor(Color.WHITE);
        start.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PINK));
        root.addView(start, new LinearLayout.LayoutParams(-1, -2));
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(permission);
            } else {
                startService(new Intent(this, OverlayService.class));
                finish();
            }
        });

        TextView hint = new TextView(this);
        hint.setText("Jika diminta, izinkan 'Tampil di atas aplikasi lain', lalu kembali dan tekan tombol.");
        hint.setTextColor(Color.GRAY);
        hint.setTextSize(13);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(8, 20, 8, 0);
        root.addView(hint);

        setContentView(root);
    }
}
