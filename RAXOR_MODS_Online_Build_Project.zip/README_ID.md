# RAXOR MODS - KERNEL EXTERNAL V1

Proyek AndroidIDE untuk floating overlay visual mandiri.

## Build di AndroidIDE
1. Ekstrak ZIP ini.
2. Buka folder `RAXOR_MODS_AndroidIDE` dari AndroidIDE.
3. Tunggu Gradle Sync selesai (internet mungkin diperlukan untuk mengunduh Android Gradle Plugin).
4. Pilih **Build > Assemble Project** atau tugas Gradle `:app:assembleDebug`.
5. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Cara pakai
1. Install APK hasil build.
2. Buka aplikasi dan tekan **AKTIFKAN FLOATING PANEL**.
3. Izinkan **Tampil di atas aplikasi lain**.
4. Kembali ke aplikasi lalu tekan tombol aktifkan lagi.
5. Geser panel dengan menyentuh area judul. MINIMIZE membuat gelembung R; tekan gelembung untuk membuka lagi.

Catatan: ini hanya overlay visual mandiri. Switch hanya demo UI dan tidak membaca/menulis memori, tidak mengubah game, dan tidak memberi fungsi cheat. `targetSdk 28` dipakai agar proyek sederhana untuk build awal; pertimbangkan peningkatan target SDK sebelum distribusi publik.

## Build online tanpa AndroidIDE (GitHub Actions)
1. Buat repository baru di GitHub.
2. Upload seluruh isi folder proyek ini ke repository (termasuk folder `.github/workflows`).
3. Buka tab **Actions** pada repository dan aktifkan Actions bila diminta.
4. Pilih workflow **Build RAXOR MODS APK** lalu tekan **Run workflow**.
5. Setelah selesai, buka hasil run dan unduh artifact `RAXOR-MODS-debug-apk`.
6. Ekstrak artifact ZIP untuk mendapatkan `app-debug.apk`.

Build online membutuhkan akun GitHub. Workflow ini membangun APK debug dari source proyek.
